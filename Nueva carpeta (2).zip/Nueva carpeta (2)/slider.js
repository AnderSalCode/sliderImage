// Variables
let slider = document.getElementById("slider");
let images = slider.querySelectorAll("img");
let currentImage = 0;

// Función para cambiar la imagen
function changeImage() {
    // Incrementamos el contador de la imagen actual
    currentImage++;

    // Si el contador supera el número de imágenes, lo restablecemos a 0
    if (currentImage >= images.length) {
        currentImage = 0;
    }

    // Mostramos la nueva imagen
    images[currentImage].style.display = "block";

    // Ocultamos la imagen anterior
    images[currentImage - 1].style.display = "none";
}

// Creamos un intervalo para cambiar la imagen cada 3 segundos
setInterval(changeImage, 3000);
